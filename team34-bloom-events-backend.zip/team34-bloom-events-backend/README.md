
macOS/LinuxWindows:
$ mkdir myproject
$ cd myproject
$ python3 -m venv venv


Activate the environment:
macOS/LinuxWindows:
$ . venv/bin/activate

Install Flask:
$ pip install Flask
